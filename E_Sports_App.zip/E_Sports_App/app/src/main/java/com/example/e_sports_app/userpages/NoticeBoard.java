package com.example.e_sports_app.userpages;


import android.app.Activity;
import android.os.Bundle;

import com.example.e_sports_app.R;

public class NoticeBoard extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_board);
    }

}