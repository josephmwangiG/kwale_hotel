package com.example.e_sports_app.dashboards;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.example.e_sports_app.R;
import com.example.e_sports_app.adminpages.ManageUsers;
import com.google.android.material.card.MaterialCardView;

public class AdminDashboard extends Activity {
MaterialCardView open_manage_users;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        open_manage_users = findViewById(R.id.open_manage_users);

        open_manage_users.setOnClickListener(v->{
            Intent intent= new Intent(getApplicationContext(), ManageUsers.class);
            startActivity(intent);
        });
    }
}