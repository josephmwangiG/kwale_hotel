package com.example.e_sports_app.adminpages;


import android.app.Activity;
import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_sports_app.R;
import com.example.e_sports_app.adapters.NoticeAdapter;

public class ManageNotices extends Activity {
Toolbar toolBar;
RecyclerView recyclerView;
NoticeAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_notices);

        toolBar = findViewById(R.id.toolBar);
        recyclerView = findViewById(R.id.my_recycler_view);
    }
}